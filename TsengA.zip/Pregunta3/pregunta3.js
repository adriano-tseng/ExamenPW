function Calcular()
{
    const radios = document.getElementsByName("medida");
    const selected = Array.from(radios).find(radio => radio.checked).value;
    let tempe = parseFloat(document.getElementById("temp").value)
    if(selected=="Celsius")
    {
        let resp = ((tempe)*(9/5))+32
        alert("La temperatura calculada es " + resp + "°F")
        tempe = 0
        document.getElementById("temp").value = ""
    }
    else
    {
        let resp = ((tempe)-(32))*(5/9)
        alert("La temperatura calculada es " + resp + "°C")
        tempe = 0
        document.getElementById("temp").value = ""
    }
}